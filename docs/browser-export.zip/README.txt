Rig Motion Lab 导出。固定 PNG 素材 + 数值动作；不是 AI 逐帧出图。
PNG 帧尺寸固定。motion.json 为本工具格式，不是 Spine JSON。
GIF 为索引色预览，不能代替含完整 Alpha 的 PNG。
